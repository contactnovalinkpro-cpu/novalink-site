# Site NOVALINK

## Ouvrir le site
Double-cliquez sur `index.html` : il s'ouvre dans votre navigateur. Rien à installer.

## Modifier les contenus
- Textes des pages, tarifs, coordonnées : fichier `build.py` (nécessite Python), puis `python3 build.py`. Sinon, ouvrez directement les `.html` avec un éditeur de texte et modifiez le texte.
- Domaine : remplacez `https://VOTRE-DOMAINE.fr` par votre vrai domaine dans tous les fichiers (VS Code : Ctrl+Maj+H, « Tout remplacer »).
- La démo ÉlecPro Services est dans le dossier `demo-elecpro` (fichiers indépendants du reste du site).
- Nouveau projet : copiez un bloc `<article class="card">` dans `realisations.html`.

## Formulaire de contact
Il utilise EmailJS (emailjs.com, offre gratuite limitée, à vérifier) : un e-mail pour NOVALINK + un e-mail de confirmation pour le client avec le récapitulatif de sa demande. Configuration : créer le compte EmailJS, connecter la boîte Gmail, créer 2 modèles (textes dans `emailjs-modeles.txt`), puis remplir les 4 valeurs de `js/config.js`. Tant que `config.js` n'est pas rempli, le site affiche que la demande n'est PAS envoyée.

## Mettre en ligne (après votre validation)
Il faut un hébergement et un nom de domaine (coûts possibles). Envoyez le contenu du dossier par FTP, ou utilisez un hébergeur statique (Netlify, Cloudflare Pages, GitHub Pages). Configurez la page `404.html` chez l'hébergeur.

## Statistiques (Google Analytics 4)
- Identifiant de mesure : `G-W42103415S` (dans `js/analytics.js`). Google Analytics ne se charge qu'après un clic sur « Accepter » dans le bandeau cookies ; le lien « Gérer les cookies » (pied de page) permet de changer d'avis.
- Rien n'est mesuré dans les deux démos (`demo-elecpro`, `demo-source-et-flamme`) ; seuls les clics vers elles depuis le site sont comptés (événement `clic_demo`). L'envoi réussi du formulaire est compté (événement `generate_lead`).
- Campagnes d'e-mails : ajoutez des paramètres UTM à vos liens, par exemple `https://novalink-sites.netlify.app/index.html?utm_source=email&utm_medium=email&utm_campaign=prospection-nov-2026`. Les visites apparaissent dans GA4 > Rapports > Acquisition.
