// NOVALINK — mesure d'audience Google Analytics 4, UNIQUEMENT après consentement.
// Rien n'est chargé, aucun cookie n'est déposé et aucune donnée n'est envoyée à Google tant que le visiteur n'a pas cliqué sur « Accepter ».
(function () {
  'use strict';

  var ID_MESURE = 'G-W42103415S';
  var CLE = 'novalink_cookies';                  // mémorisation du choix (navigateur du visiteur)
  var DUREE_CHOIX = 182 * 24 * 3600 * 1000;      // 6 mois
  var DUREE_COOKIE_GA = 390 * 24 * 3600;         // ~13 mois (secondes)
  var charge = false;
  var actif = false;
  var banniere = null;

  function lireChoix() {
    try {
      var o = JSON.parse(localStorage.getItem(CLE));
      if (o && (o.c === 'oui' || o.c === 'non') && Date.now() - o.t < DUREE_CHOIX) return o.c;
    } catch (e) {}
    return null;
  }
  function ecrireChoix(c) {
    try { localStorage.setItem(CLE, JSON.stringify({ c: c, t: Date.now() })); } catch (e) {}
  }

  // Adresse envoyée à Google : sans paramètres d'URL, sauf les paramètres de campagne utm_* (sans valeur contenant un « @ »).
  function adressePage() {
    var garde = [];
    try {
      new URLSearchParams(location.search).forEach(function (v, k) {
        if (/^utm_[a-z0-9_]+$/i.test(k) && v.length <= 100 && v.indexOf('@') === -1) {
          garde.push(encodeURIComponent(k) + '=' + encodeURIComponent(v));
        }
      });
    } catch (e) {}
    return location.origin + location.pathname + (garde.length ? '?' + garde.join('&') : '');
  }
  // Page d'origine : sans paramètres ni ancre.
  function adresseOrigine() {
    if (!document.referrer) return '';
    try { var u = new URL(document.referrer); return u.origin + u.pathname; } catch (e) { return ''; }
  }

  function charger() {
    window['ga-disable-' + ID_MESURE] = false;
    actif = true;
    if (charge) return;
    charge = true;
    window.dataLayer = window.dataLayer || [];
    window.gtag = function () { window.dataLayer.push(arguments); };
    gtag('js', new Date());
    gtag('consent', 'default', {
      analytics_storage: 'granted', ad_storage: 'denied', ad_user_data: 'denied', ad_personalization: 'denied'
    });
    gtag('config', ID_MESURE, {
      allow_google_signals: false,
      allow_ad_personalization_signals: false,
      cookie_expires: DUREE_COOKIE_GA,
      page_location: adressePage(),
      page_referrer: adresseOrigine()
    });
    var s = document.createElement('script');
    s.async = true;
    s.src = 'https://www.googletagmanager.com/gtag/js?id=' + ID_MESURE;
    document.head.appendChild(s);
  }

  function supprimerCookies() {
    var exp = 'expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/';
    document.cookie.split(';').forEach(function (c) {
      var nom = c.split('=')[0].trim();
      if (!/^_(ga|gid|gat)/.test(nom)) return;
      document.cookie = nom + '=;' + exp;
      var h = location.hostname.split('.');
      for (var i = 0; i < h.length - 1; i++) {
        document.cookie = nom + '=;' + exp + ';domain=.' + h.slice(i).join('.');
        document.cookie = nom + '=;' + exp + ';domain=' + h.slice(i).join('.');
      }
    });
  }
  function desactiver() {
    actif = false;
    window['ga-disable-' + ID_MESURE] = true;
    supprimerCookies();
  }

  function fermer() {
    if (banniere && banniere.parentNode) banniere.parentNode.removeChild(banniere);
    banniere = null;
  }
  function ouvrir(focus) {
    if (banniere) return;
    banniere = document.createElement('div');
    banniere.id = 'cookie-banner';
    banniere.setAttribute('role', 'dialog');
    banniere.setAttribute('aria-modal', 'true');
    banniere.setAttribute('aria-labelledby', 'cb-titre');
    banniere.setAttribute('aria-describedby', 'cb-texte');
    banniere.innerHTML =
      '<div class="cb-carte">' +
      '<h2 id="cb-titre">Votre vie privée</h2>' +
      '<p id="cb-texte">Nous utilisons Google Analytics pour mesurer la fréquentation de ce site (pages consultées, provenance des visites). ' +
      'Aucun cookie de mesure n\u2019est déposé sans votre accord. ' +
      '<a href="confidentialite.html#cookies">En savoir plus</a></p>' +
      '<div class="cb-btns">' +
      '<button type="button" class="btn dark" data-choix="non">Refuser</button>' +
      '<button type="button" class="btn dark" data-choix="oui">Accepter</button>' +
      '</div></div>';
    banniere.addEventListener('click', function (e) {
      var b = e.target.closest && e.target.closest('[data-choix]');
      if (!b) return;
      if (b.getAttribute('data-choix') === 'oui') { ecrireChoix('oui'); charger(); }
      else { ecrireChoix('non'); desactiver(); }
      fermer();
    });
    document.body.appendChild(banniere);
    if (focus) { var premier = banniere.querySelector('button'); if (premier) premier.focus(); }
  }

  function envoyer(nom, params) {
    if (actif && typeof window.gtag === 'function') window.gtag('event', nom, params || {});
  }

  function demarrer() {
    // Lien « Gérer les cookies » (pied de page et page Confidentialité)
    document.addEventListener('click', function (e) {
      var l = e.target.closest && e.target.closest('[data-cookies]');
      if (l) { e.preventDefault(); ouvrir(true); }
    });

    // Clics vers les deux démonstrations
    function clicDemo(e) {
      var a = e.target.closest && e.target.closest('a[href]');
      if (!a) return;
      var h = a.getAttribute('href') || '';
      var demo = h.indexOf('demo-elecpro/') > -1 ? 'elecpro' : (h.indexOf('demo-source-et-flamme/') > -1 ? 'source-et-flamme' : '');
      if (demo) envoyer('clic_demo', { demo_nom: demo, transport_type: 'beacon' });
    }
    document.addEventListener('click', clicDemo);
    document.addEventListener('auxclick', clicDemo);

    // Formulaire de contact : événement uniquement quand l'envoi a réussi (message de succès affiché par main.js).
    // Aucune donnée saisie par le visiteur n'est transmise.
    var msg = document.getElementById('msg');
    if (msg && window.MutationObserver) {
      new MutationObserver(function () {
        if (msg.className === 'ok') envoyer('generate_lead', { form_id: 'contact' });
      }).observe(msg, { childList: true });
    }

    var choix = lireChoix();
    if (choix === 'oui') charger();
    else if (choix === null) ouvrir(true);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', demarrer);
  else demarrer();
})();
