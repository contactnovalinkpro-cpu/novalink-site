// Réglages du formulaire de contact (EmailJS).
window.NOVALINK_EMAIL={
  publicKey:'F1on9gAo5rXm-brdl',
  serviceId:'service_yi729q1',
  templateEntreprise:'template_x0s8ikw',
  templateClient:'template_evjbtzr'
};
