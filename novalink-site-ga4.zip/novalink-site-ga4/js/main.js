const b=document.querySelector('.burger'),m=document.getElementById('menu');
b&&b.addEventListener('click',()=>{const o=m.classList.toggle('open');b.setAttribute('aria-expanded',o)});
const io=new IntersectionObserver(e=>e.forEach(x=>{if(x.isIntersecting){x.target.classList.add('in');io.unobserve(x.target)}}),{threshold:.12});
document.querySelectorAll('.reveal').forEach(el=>io.observe(el));
const t=document.getElementById('top');
if(t){addEventListener('scroll',()=>t.style.display=scrollY>500?'block':'none');t.onclick=()=>scrollTo({top:0})}
const f=document.getElementById('form');
if(f){f.addEventListener('submit',async ev=>{ev.preventDefault();
 const msg=document.getElementById('msg'),btn=f.querySelector('button[type=submit]');
 const show=(c,s)=>{msg.className=c;msg.textContent=s};
 if(!f.checkValidity()){f.reportValidity();return}
 if(f.website.value)return;
 const C=window.NOVALINK_EMAIL||{};
 if(Object.values(C).some(v=>!v||String(v).startsWith('VOTRE_'))){show('err',"Le formulaire n'est pas encore configuré : votre demande n'a PAS été envoyée. Écrivez-nous à contact.novalink.pro@gmail.com.");return}
 const d=Object.fromEntries(new FormData(f));delete d.website;
 d.consentement=f.consentement.checked?'Oui':'Non';
 d.date=new Date().toLocaleString('fr-FR');
 const send=t=>fetch('https://api.emailjs.com/api/v1.0/email/send',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({service_id:C.serviceId,template_id:t,user_id:C.publicKey,template_params:d})});
 btn.disabled=true;
 try{const r=await send(C.templateEntreprise);if(!r.ok)throw 0;
  let ok=true;try{ok=(await send(C.templateClient)).ok}catch(e){ok=false}
  f.reset();show('ok',ok?"✅ Merci, votre demande a bien été envoyée ! Un e-mail de confirmation avec le récapitulatif de tout ce que vous avez écrit vient d'être envoyé à l'adresse "+d.email+". Pensez à vérifier votre dossier courrier indésirable (spam) si vous ne le voyez pas dans votre boîte de réception.":"✅ Votre demande a bien été envoyée, mais l'e-mail de confirmation n'a pas pu être adressé à "+d.email+".");msg.scrollIntoView({behavior:'smooth',block:'center'})}
 catch(e){show('err',"L'envoi a échoué. Veuillez réessayer ou nous écrire à contact.novalink.pro@gmail.com.")}
 btn.disabled=false})}
